﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Okna.Windows
{
    public partial class LoginWindow : Window
    {
        public LoginWindow()
        {
            InitializeComponent();
        }
        Action<string, string> _onClose;//atribut pro uložení callback funcke (delegáta), která bude vykonána po potvrzení tlačítkem
        public LoginWindow(Action<string, string> onClose)//přetížení konstruktoru
        {
            InitializeComponent();
            _onClose = onClose;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            //kontrola, zda _onClose bylo inicializováno
            if (_onClose != null) 
                _onClose(NameInput.Text, PasswordInput.Text);
            Close();//uzavření okna
        }
    }
}
