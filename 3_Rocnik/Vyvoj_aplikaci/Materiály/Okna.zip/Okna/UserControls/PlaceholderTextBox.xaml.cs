﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Okna.UserControls
{

    public partial class PlaceholderTextBox : UserControl
    {
        //registrace vlastnosti Placeholder - první parametr metody Registr je jméno registrované vlastnosti, následuje datový typ vlastnosti, poté datový typ vlastníka vlastnosti a nakonec základní hodnota vlastnosti
        public static DependencyProperty PlaceholderProperty = DependencyProperty.Register(nameof(Placeholder), typeof(string), typeof(PlaceholderTextBox), new PropertyMetadata(""));
        //definice vlastnosti Placeholder
        public string Placeholder
        {
            get => (string)GetValue(PlaceholderProperty); //Načtení hodnoty
            set => SetValue(PlaceholderProperty, value); //Uložení hodnoty
        }
        //To samé jako u vlastnosti Placeholder
        public static DependencyProperty TextProperty = DependencyProperty.Register(nameof(Text), typeof(string), typeof(PlaceholderTextBox), new PropertyMetadata(""));
        public string Text
        {
            get => (string)GetValue(TextProperty);
            set => SetValue(TextProperty, value);
        }

        public static DependencyProperty CornerRadiusProperty = DependencyProperty.Register(nameof(CornerRadius), typeof(CornerRadius), typeof(PlaceholderTextBox), new PropertyMetadata(new CornerRadius(0)));
        public CornerRadius CornerRadius
        {
            get => (CornerRadius)GetValue(CornerRadiusProperty);
            set => SetValue(CornerRadiusProperty, value);
        }

        public static DependencyProperty PlaceholderColorProperty = DependencyProperty.Register(nameof(PlaceholderColor),typeof(Brush), typeof(PlaceholderTextBox), new PropertyMetadata(Brushes.Black));
        public Brush PlaceholderColor
        {
            get => (Brush)GetValue(PlaceholderColorProperty);
            set => SetValue(PlaceholderColorProperty, value);
        }

        public static DependencyProperty IsPasswordProperty = DependencyProperty.Register(nameof(IsPassword), typeof(bool), typeof(PlaceholderTextBox), new PropertyMetadata(false));
        public bool IsPassword
        {
            get => (bool)GetValue(IsPasswordProperty);
            set { SetValue(IsPasswordProperty, value); TextInput.Visibility = value ? Visibility.Collapsed : Visibility.Visible; PasswordInput.Visibility = value ? Visibility.Visible : Visibility.Collapsed; }
        }
        public PlaceholderTextBox()
        {
            InitializeComponent();
            Loaded += (s, e) =>
            {
                IsPassword = IsPassword;
            };
        }
        //Metoda, která se stará o skrývání a zobrazování placeholderu. Metoda se vykoná poždé, když dojde ke změně hodnoty v textboxu, kterému byla přiřazena.
        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            var textbox = (TextBox)sender;//textbox do kterému je tato metoda nastavena 
            if (textbox == null || textbox.Visibility == Visibility.Collapsed) return;
            PasswordInput.Password = textbox.Text;
            if (!string.IsNullOrEmpty(textbox.Text))//pokud bude hodnota proměnné textbox null znamená to, že metoda nebyla přiřazena textboxu, ale jinému elementu.
            {
                PLaceholderElement.Visibility = Visibility.Collapsed;//Pokud v textboxu je nějaký text dojde ke skrytí placeholderu.
            }
            else
            {
                PLaceholderElement.Visibility = Visibility.Visible;//Pokud v textboxu není žádný text dojde k zobrazení placeholderu.
            }
        }

        private void PasswordBox_PasswordChanged(object sender, RoutedEventArgs e)
        {
            var passwordBox = (PasswordBox)sender;
            if (passwordBox != null)
            {
                TextInput.Text = passwordBox.Password;
                if (!string.IsNullOrEmpty(Text)) 
                {
                    PLaceholderElement.Visibility = Visibility.Collapsed;//Pokud v passwordBoxu je nějaký text dojde ke skrytí placeholderu.
                }
                else
                {
                    PLaceholderElement.Visibility = Visibility.Visible;//Pokud v passwordBoxu není žádný text dojde k zobrazení placeholderu.
                }
            }
        }
        //metoda pro ukázání a skrytí hesla
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (TextInput.Visibility == Visibility.Visible) 
            {
                TextInput.Visibility = Visibility.Collapsed;
                PasswordInput.Visibility = Visibility.Visible;
                PasswordInput.Focus();
            } else
            {
                TextInput.Visibility = Visibility.Visible;
                PasswordInput.Visibility = Visibility.Collapsed;
                TextInput.Focus();
                TextInput.CaretIndex = PasswordInput.Password.Length;
            }
        }
    }
}
