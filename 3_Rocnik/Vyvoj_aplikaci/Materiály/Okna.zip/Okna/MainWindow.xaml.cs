﻿using Okna.Windows;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Okna
{
    public partial class MainWindow : Window
    {
        LoginWindow _loginWindow;
        Action<string, string> _login;//vytvořenní atribut pro uložení delegáta (speciální funkce uložitelné do atributu/proměnné) Action. Vstupem do delegáta budou v tomto případdě dva stringy.
        public MainWindow()
        {
            InitializeComponent();
            _login = (string name, string password) =>//inicializace delegáta na novou funkci - funkce je zapsáno pomocí lambda operátoru ale chová se jako normální metoda
            {
                NameLabel.Content = name;
                PasswordLabel.Content = password;
            };
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            _loginWindow = new LoginWindow(_login);//vytvoření nového okna a předání delegáta nastavující popisky
            _loginWindow.Show();
        }
    }
}
