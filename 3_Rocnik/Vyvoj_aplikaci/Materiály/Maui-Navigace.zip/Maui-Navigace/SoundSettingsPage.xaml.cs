namespace MauiShellNavigation;

public partial class SoundSettingsPage : ContentPage
{
	public SoundSettingsPage()
	{
		InitializeComponent();
	}

    private void Button_Clicked(object sender, EventArgs e)
    {
		Shell.Current.GoToAsync("//Home");
    }
}