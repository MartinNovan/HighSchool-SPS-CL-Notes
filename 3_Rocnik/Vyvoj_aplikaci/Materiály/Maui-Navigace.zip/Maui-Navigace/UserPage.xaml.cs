namespace MauiShellNavigation;

[QueryProperty(nameof(User), nameof(User))]
public partial class UserPage : ContentPage
{
	private User _user;
    public User User { get => _user; set 
		{
            _user = value;
			_user.Name = _user.Name;
            this.BindingContext = _user;
        }
	}
    public UserPage()
	{
		InitializeComponent();
	}

	void Update()
	{
		if (_user != null)
		{
			UserName.Text = _user.Name;
			UserEmail.Text = _user.Email;
			UserPassword.Text = _user.Password;
		}
	}
}