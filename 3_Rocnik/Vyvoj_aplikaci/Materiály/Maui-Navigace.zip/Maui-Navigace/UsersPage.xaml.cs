using System.Collections.ObjectModel;

namespace MauiShellNavigation;

public partial class UsersPage : ContentPage
{
    string[] _names = new string[]
    {
        "John",
        "Jane",
        "Sam",
        "Lisa",
        "Tom",
        "Anna",
        "Mike",
        "Sara",
        "Chris",
        "Kate",
    };

    string[] _surnames = new string[]
    {
        "Doe",
        "Smith",
        "Johnson",
        "Williams",
        "Brown",
        "White",
        "Green",
        "Black",
    };
    public ObservableCollection<User> Users { get; set; } = new ObservableCollection<User>();
    public UsersPage()
    {
        InitializeComponent();
        for (int i = 0; i < 10; i++)
        {
            Users.Add(GetRandomUser());
        }
        BindingContext = this;
    }

    private User GetRandomUser()
    {
        string name = _names[Random.Shared.Next(_names.Length)];
        string surname = _surnames[Random.Shared.Next(_surnames.Length)];
        string email = $"{name.ToLower()}.{surname.ToLower()}@example.com";
        string password = $"{name.ToLower()}{surname.ToLower()}123";
        return new User() {
            Name = $"{name} {surname}",
            Email = email,
            Password = password
        };
    }

    private void ListView_ItemTapped(object sender, ItemTappedEventArgs e)
    {
        User? user = e.Item as User;
        if (user != null)
        {
            Shell.Current.GoToAsync($"user", new Dictionary<string, object>
            {
                { nameof(User), user }
            });
        }
    }
}