﻿using CommunityToolkit.Mvvm.ComponentModel;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MauiShellNavigation
{
    public partial class User : ObservableObject
    {
        [ObservableProperty]
        private string name;
        [ObservableProperty]
        private string email;
        [ObservableProperty]
        private string password;

        public override string ToString()
        {
            return $"{Name} ({Email})";
        }
    }
}
