namespace MauiShellNavigation;

public partial class AppearanceSettingsPage : ContentPage
{
	public AppearanceSettingsPage()
	{
		InitializeComponent();
	}
}